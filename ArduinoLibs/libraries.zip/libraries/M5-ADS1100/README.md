# M5-ADS1100

## Overview

### SKU:U013/U069

Contains M5Stack **Unit & Hat ADC** related case programs.


## Related Link

[Document & Datasheet - M5Unit-ADC](https://docs.m5stack.com/en/unit/adc)

[Document & Datasheet - M5Hat-ADC](https://docs.m5stack.com/en/hat/hat-adc)

## License

[Unit & Hat ADC - MIT](LICENSE)
