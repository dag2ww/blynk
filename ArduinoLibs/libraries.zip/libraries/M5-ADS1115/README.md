# M5-ADS1115

## Overview

### SKU:U086/U087

Contains M5Stack **UNIT Ameter & Vmeter** related case programs.

## Related Link

[Document & Datasheet - M5Unit-Ameter](https://docs.m5stack.com/en/unit/ameter)

[Document & Datasheet - M5Unit-Vmeter](https://docs.m5stack.com/en/unit/vmeter)


## License

[UNIT Ameter & Vmeter - MIT](LICENSE)

