# M5-FPC1020A

## Overview

### SKU:U008 & U074 & A066

M5Stack **Unit&Module FINGER** integrated the FPC1020A capacitive fingerprint recognition module and Fingerprint recognition algorithm chip.

## Related Link

- [Document & Datasheet - M5Unit-Finger](https://docs.m5stack.com/en/unit/finger)

- [Document & Datasheet - M5Hat-Finger](https://docs.m5stack.com/en/hat/hat-finger)

- [Document & Datasheet - M5Module-Finger](https://docs.m5stack.com/en/module/faces_finger)

## License

[M5-FPC1020A - MIT](LICENSE)

