# M5Unit-EXTIO2

## Overview

Contains case programs of M5Stack UNIT EXT.IO2.

## Related Link

- [Document & Datasheet - M5Unit-EXTIO2](https://docs.m5stack.com/en/unit/extio2)
- [Firmware & Register](https://github.com/m5stack/M5Unit-EXTIO2-Internal-FW)

## License

- [M5Unit-EXTIO2 - MIT](LICENSE)
