# M5Unit-Encoder

## Overview

### SKU:U135

Contains case programs of M5Stack Unit Encoder.

## Related Link

- [Document & Datasheet - M5Unit-Encoder](https://docs.m5stack.com/en/unit/encoder)

## License

[M5Unit-Encoder - MIT](LICENSE)
