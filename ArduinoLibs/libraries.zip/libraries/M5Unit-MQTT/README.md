# M5Unit-MQTT

## Overview

Contains M5Stack **UNIT MQTT** related case programs. Realize MQTT server connection, subscribe and publish information.

## Related Link

[Document & AT Command - M5Unit-MQTT](https://docs.m5stack.com/en/unit/mqtt)

## License

[M5Unit-MQTT - MIT](LICENSE)

