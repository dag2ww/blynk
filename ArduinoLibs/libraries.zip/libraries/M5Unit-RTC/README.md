# M5Unit-RTC

## Overview

### SKU:U126

M5Stack-**UNIT RTC** related programs.compatible with BM8563 and HYM8563.

## Related Link

[Document & Datasheet - M5Unit-RTC](https://docs.m5stack.com/en/unit/rtc)

## License

[M5Unit-RTC - MIT](LICENSE)
